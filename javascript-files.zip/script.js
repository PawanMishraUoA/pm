const $ = (s, root=document) => root.querySelector(s);
const $$ = (s, root=document) => [...root.querySelectorAll(s)];

const nav = $('#nav');
const menuToggle = $('#menuToggle');
menuToggle.addEventListener('click', () => {
  const open = nav.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded', String(open));
  menuToggle.innerHTML = open ? '<i class="fa-solid fa-xmark"></i>' : '<i class="fa-solid fa-bars"></i>';
});
$$('#nav a').forEach(a => a.addEventListener('click', () => {
  nav.classList.remove('open');
  menuToggle.setAttribute('aria-expanded','false');
  menuToggle.innerHTML='<i class="fa-solid fa-bars"></i>';
}));

const themeToggle = $('#themeToggle');
const storedTheme = localStorage.getItem('pm-theme');
if (storedTheme === 'dark') document.body.classList.add('dark');
function updateThemeIcon(){
  themeToggle.innerHTML = document.body.classList.contains('dark')
    ? '<i class="fa-solid fa-sun"></i>'
    : '<i class="fa-solid fa-moon"></i>';
}
updateThemeIcon();
themeToggle.addEventListener('click', () => {
  document.body.classList.toggle('dark');
  localStorage.setItem('pm-theme', document.body.classList.contains('dark') ? 'dark' : 'light');
  updateThemeIcon();
});

// Google Scholar values are only rendered when verified numeric values exist in data.js.
const scholarMap = [
  ['#scholarCitations', scholarProfile?.citations],
  ['#scholarHIndex', scholarProfile?.hIndex],
  ['#scholarI10Index', scholarProfile?.i10Index]
];
scholarMap.forEach(([selector, value]) => {
  const el = $(selector);
  if (el && value !== null && value !== undefined && value !== '') el.textContent = value;
});

const publicationList = $('#publicationList');
const publicationSummary = $('#publicationSummary');
const label = {
  journal: 'Journal',
  conference: 'Conference',
  'book-chapter': 'Book Chapter',
  patent: 'Patent'
};

function renderPublicationSummary(){
  const counts = publications.reduce((acc,p) => {
    acc[p.type] = (acc[p.type] || 0) + 1;
    return acc;
  }, {});
  publicationSummary.innerHTML = `
    <div class="pub-stat"><strong>${publications.length}</strong><span>Listed records</span></div>
    <div class="pub-stat"><strong>${counts.journal || 0}</strong><span>Journals</span></div>
    <div class="pub-stat"><strong>${counts.conference || 0}</strong><span>Conferences</span></div>
    <div class="pub-stat"><strong>${counts['book-chapter'] || 0}</strong><span>Book Chapters</span></div>
    <div class="pub-stat"><strong>${counts.patent || 0}</strong><span>Patents listed</span></div>`;
}

function renderPublications(filter='all') {
  const list = filter === 'all' ? publications : publications.filter(p => p.type === filter);
  publicationList.innerHTML = list.map(p => `
    <article class="pub-card reveal">
      <div class="pub-year">${p.year}</div>
      <div>
        <span class="pub-type ${p.type}">${label[p.type]}</span>
        <h3>${p.title}</h3>
        <p>${p.authors}</p>
        <small>${p.venue}${p.note ? ` · ${p.note}` : ''}${p.link ? ` · <a href="${p.link}" target="_blank" rel="noopener">DOI</a>` : ''}</small>
      </div>
    </article>`).join('');
  observeReveals();
}

renderPublicationSummary();
$$('.filter').forEach(btn => btn.addEventListener('click', () => {
  $$('.filter').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
  renderPublications(btn.dataset.filter);
}));
renderPublications();

let observer;
function observeReveals(){
  if (observer) observer.disconnect();
  observer = new IntersectionObserver(entries => entries.forEach(e => {
    if(e.isIntersecting) e.target.classList.add('visible');
  }), {threshold:.12});
  $$('.reveal').forEach(el => observer.observe(el));
}
observeReveals();
